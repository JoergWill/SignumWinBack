MySql-DLL Versionen
===================

V1.0.10.1	L�uft mit MySQL-Server 3.23.48	alte Passw�rter OK	Command-Builder funktioniert !!!
========================================================================================================
V5.0.2		L�uft mit MySQL-Server 3.32.48	alte Passw�rter OK	Command-Builder funktioniert nicht !!
V5.2.6		L�uft mit MySQL-Server 3.23.48	alte Passw�rter OK	Command-Builder funktioniert nicht !!
========================================================================================================
V6.4.6		L�uft nur mit MySQL-Server 5.0	alte Passw�rter OK	Command-Builder funktioniert
V6.8.7		L�uft nur mit MySQL-Server 5.0	keine alten Passw�rter	Command-Builder ?
========================================================================================================
