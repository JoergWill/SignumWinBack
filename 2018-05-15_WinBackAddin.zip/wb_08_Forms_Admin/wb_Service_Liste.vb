﻿Imports WeifenLuo.WinFormsUI.Docking

Public Class wb_Service_Liste
    Inherits DockContent
End Class
