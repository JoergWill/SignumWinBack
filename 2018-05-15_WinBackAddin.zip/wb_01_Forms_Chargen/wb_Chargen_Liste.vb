﻿Imports WeifenLuo.WinFormsUI.Docking

Public Class wb_Chargen_Liste
    Inherits DockContent
End Class
