﻿Public Interface IMainMenu

    Function ExecuteCmd(Cmd As String, Prm As String) As Boolean
    Property DkPnlConfigFileName As String

End Interface
