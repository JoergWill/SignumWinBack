﻿Imports WeifenLuo.WinFormsUI.Docking

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class wb_Rohstoffe_Verwendung
    Inherits DockContent
    'Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.HisDataGridView = New Global.WinBack.wb_DataGridViewVerwendung()
        CType(Me.HisDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'HisDataGridView
        '
        Me.HisDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HisDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.HisDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HisDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.HisDataGridView.Name = "HisDataGridView"
        Me.HisDataGridView.ReadOnly = True
        Me.HisDataGridView.ShowCellErrors = False
        Me.HisDataGridView.Size = New System.Drawing.Size(528, 398)
        Me.HisDataGridView.TabIndex = 3
        '
        'wb_Rohstoffe_Verwendung
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(528, 398)
        Me.Controls.Add(Me.HisDataGridView)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "wb_Rohstoffe_Verwendung"
        Me.Text = "Rohstoffe Verwendung"
        CType(Me.HisDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents HisDataGridView As wb_DataGridViewVerwendung
End Class
