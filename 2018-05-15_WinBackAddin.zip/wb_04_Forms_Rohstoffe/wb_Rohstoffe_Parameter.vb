﻿Imports WeifenLuo.WinFormsUI.Docking

Public Class wb_Rohstoffe_Parameter
    Inherits DockContent

End Class