﻿Public Class wb_Credentials
    ' WinBack-Cloud (Hetzner)

    Public Const WinBackCloud_Url = "http://nwt.winback.de:8080/nwt"
    Public Const WinBackCloud_Pass = "bnd0OldpTmJBY0s="

    ' Datenlink 2.0
    ' User: jw@winback.de
    ' Pass: de2!a6
    Public Const Datenlink_Url = "http://api.datenlink.info/basic/2.0/"
    Public Const Datenlink_CAT = "37FB090516F091A8236AD70D16543EF3BDF91B23"
    Public Const Datenlink_PAT = "51A7C4A02782876A05CC8EF7398E596E35390BB2"

    'Master-User
    Public Const WinBackMasterUser = "709760"

    'Passwort Verschlüsselung
    Public Const Passwd3Des = "de2!a6DE2"

End Class
