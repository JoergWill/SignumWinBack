﻿Imports System.Drawing
Imports System.Windows.Forms

Public Class wb_EditControl
    Inherits Infralution.Controls.VirtualTree.CellEditor


    Public Overrides Sub LayoutControl(control As Control, bounds As Rectangle, showControl As Boolean)
        MyBase.LayoutControl(control, bounds, showControl)
    End Sub
End Class
