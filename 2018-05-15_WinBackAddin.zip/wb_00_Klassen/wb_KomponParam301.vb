﻿Imports WinBack.wb_Functions
Imports WinBack.wb_Global
Imports WinBack.wb_KomponParam301_Global

Public Class wb_KomponParam301
    Inherits wb_ChangeLog

    Private Structure Typ301
        Public _Allergen As AllergenInfo
        Public _Naehrwert As Double
        Public _FehlerKompName As String
    End Structure

    'Array aller Nährwerte/Allergene
    Private NaehrwertInfo(maxTyp301) As Typ301
    Private _TimeStamp
    Private _IsCalculated

    ''' <summary>
    ''' Nach der Initialisierung sind die Nährwerte nicht berechnet
    ''' </summary>
    Public Sub New()
        _IsCalculated = False
    End Sub

    ''' <summary>
    ''' Gibt False zurück, wenn das Array leer bzw. noch nicht berechnet ist (Lesen aus DB erforderlich)
    ''' True, wenn Daten vorhanden sind.
    ''' </summary>
    ''' <returns>Boolean - Nährwerte sind ermittelt und berechnet</returns>
    Public Property IsCalculated As Boolean
        Get
            Return _IsCalculated
        End Get
        Set(value As Boolean)
            _IsCalculated = value
        End Set
    End Property

    Public Property TimeStamp As DateTime
        Get
            Return _TimeStamp
        End Get
        Set(value As DateTime)
            _TimeStamp = value
        End Set
    End Property

    Public Property Allergen(index As Integer) As AllergenInfo
        Get
            If IsAllergen(index) Then
                Return NaehrwertInfo(index)._Allergen
            Else
                Return AllergenInfo.ERR
            End If
        End Get
        Set(value As AllergenInfo)
            If IsAllergen(index) Then
                NaehrwertInfo(index)._Allergen = value
                _IsCalculated = True
            End If
        End Set
    End Property

    Public Property Naehrwert(index As Integer) As Double
        Get
            If Not IsAllergen(index) Then
                Return NaehrwertInfo(index)._Naehrwert
            Else
                Return 0.0
            End If
        End Get
        Set(value As Double)
            If Not IsAllergen(index) Then
                NaehrwertInfo(index)._Naehrwert = value
                _IsCalculated = True
            End If
        End Set
    End Property

    Public Property Wert(index As Integer) As String
        Get
            If IsAllergen(index) Then
                Return NaehrwertInfo(index)._Allergen
            Else
                Return NaehrwertInfo(index)._Naehrwert
            End If
        End Get
        Set(value As String)
            If IsAllergen(index) Then
                'Änderungen loggen
                NaehrwertInfo(index)._Allergen = ChangeLogAdd(LogType.Alg, index, NaehrwertInfo(index)._Allergen, StringtoAllergen(value))
            Else
                'Änderungen loggen
                NaehrwertInfo(index)._Naehrwert = ChangeLogAdd(LogType.Nrw, index, NaehrwertInfo(index)._Naehrwert, StrToDouble(value))
            End If
        End Set
    End Property

    Public Property FehlerKompName(index As Integer) As String
        Get
            Return NaehrwertInfo(index)._FehlerKompName
        End Get
        Set(value As String)
            NaehrwertInfo(index)._FehlerKompName = value
        End Set
    End Property

    Public WriteOnly Property dlNaehrWert(index As String) As String
        Set(value As String)
            Dim idx As Integer = DatenLinkToIndex(index)
            If idx > 0 Then
                Try
                    Naehrwert(idx) = CDbl(value)
                Catch ex As Exception
                    Trace.WriteLine("Fehler bei DatenLink - Index = " & index & " Wert = " & value)
                End Try
            Else
                Trace.WriteLine("Fehler bei DatenLink - Index " & index & " nicht definiert")
            End If
        End Set
    End Property

    Public WriteOnly Property dlAllergen(index As String) As String
        Set(value As String)
            Dim idx As Integer = DatenLinkToIndex(index)
            If idx > 0 Then
                Select Case value
                    Case "CONTAINED"
                        Allergen(idx) = AllergenInfo.C
                    Case "MAY_CONTAINED"
                        Allergen(idx) = AllergenInfo.T
                    Case Else
                        Allergen(idx) = AllergenInfo.ERR
                End Select
            Else
                Trace.WriteLine("Fehler bei DatenLink - Index " & index & " nicht definiert")
            End If
        End Set
    End Property

    Public Sub ClearReport()
        ChangeLogClear()
    End Sub

    Public Function GetReport(Optional ReportAll As Boolean = vbFalse) As String
        Return ChangeLogReport(ReportAll)
    End Function

    ''' <summary>
    ''' Addiert alle Nährwerte und Allergene zum übergebenen KomponentenParameter-Array
    ''' Die Bezeichnungen der fehlerhaften Komponenten werden aneinander gehängt
    ''' </summary>
    ''' <param name="_ktTyp301"></param>
    Public Sub AddNwt(ByRef _ktTyp301 As wb_KomponParam301, Faktor As Double)
        For i = 0 To maxTyp301
            If IsAllergen(i) Then
                _ktTyp301.Allergen(i) = AddNwtAllergen(_ktTyp301.Allergen(i), Allergen(i))
            Else
                _ktTyp301.Naehrwert(i) += Naehrwert(i) * Faktor
            End If
            If FehlerKompName(i) <> "" Then
                If _ktTyp301.FehlerKompName(i) = "" Then
                    _ktTyp301.FehlerKompName(i) = FehlerKompName(i)
                Else
                    _ktTyp301.FehlerKompName(i) += "/" & FehlerKompName(i)
                End If
            End If
        Next
    End Sub

    ''' <summary>
    ''' Addiert die Allergen-Info. Bei der Addition wird der jeweils größere Wert zurückgegeben.
    ''' Die Reihenfolge der Kontanten in wb_global entspricht der Reihenfolge der Wertigkeit.
    ''' </summary>
    ''' <param name="Allergen1"></param>
    ''' <param name="Allergen2"></param>
    Private Function AddNwtAllergen(Allergen1 As AllergenInfo, Allergen2 As AllergenInfo) As AllergenInfo

        'die Aufzählung der Konstanten entspricht der Reihenfolge der Wertigkeit.
        If Allergen1 > Allergen2 Then
            Return Allergen1
        Else
            Return Allergen2
        End If
    End Function
End Class
