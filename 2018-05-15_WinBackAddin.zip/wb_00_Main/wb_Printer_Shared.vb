﻿Imports combit.ListLabel22
Imports combit.ListLabel22.DataProviders

Public Class wb_Printer_Shared
    Public Shared LL As New ListLabel()

End Class
