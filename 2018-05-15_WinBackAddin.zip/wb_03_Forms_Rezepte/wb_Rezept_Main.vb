﻿Imports Signum.OrgaSoft
Imports Signum.OrgaSoft.Common
Imports Signum.OrgaSoft.GUI
Imports WeifenLuo.WinFormsUI.Docking

Public Class wb_Rezept_Main
    Implements IExternalFormUserControl

    'Default Fenster
    Public RezeptListe As New wb_Rezept_Liste
    Public RezeptDetails As New wb_Rezept_Details

    'alle anderen Fenster werden zur Laufzeit erzeugt
    Public RezeptHinweise As wb_Rezept_Hinweise
    Public RezeptHistorie As wb_Rezept_Historie

    Public Sub New(ServiceProvider As IOrgasoftServiceProvider)
        MyBase.New(ServiceProvider)
    End Sub

    ''' <summary>
    ''' Fenster-Name (Caption). Wird von Init() aufgerufen
    ''' </summary>
    ''' <returns></returns>
    Public Overrides ReadOnly Property FormText As String
        Get
            Return "WinBack Rezeptverwaltung"
        End Get
    End Property

    ''' <summary>
    ''' Eindeutiger Name für die Basis-Form. 
    ''' Unter diesem Namen werden die Einstellungen in der winback.ini gespeichert.
    ''' 
    ''' Die DockPanel-Konfiguration wird gespeichert unter wbXXXXYYYY.xml, dabei ist XXXX der FormName und YYYY der Layout-Name.
    ''' </summary>
    ''' <returns></returns>
    Public Overrides ReadOnly Property FormName As String
        Get
            Return "Rezepte"
        End Get
    End Property

    Public Overrides Sub SetDefaultLayout()
        RezeptDetails.Show(DockPanel, DockState.DockTop)
        RezeptDetails.CloseButtonVisible = False
        RezeptListe.Show(DockPanel, DockState.DockLeft)
        RezeptListe.CloseButtonVisible = False
    End Sub

    Public Shadows ReadOnly Property ContextTabs As GUI.ITab() Implements IExternalFormUserControl.ContextTabs
        Get
            If _ContextTabs Is Nothing Then
                _ContextTabs = New List(Of GUI.ITab)
                ' Fügt dem Ribbon ein neues RibbonTab hinzu
                Dim oNewTab = _MenuService.AddContextTab("RezeptVerwaltung", "WinBack-Rezepte", "Verwaltung der WinBack-Rezepturen")
                ' Das neue RibbonTab erhält eine Gruppe
                Dim oGrp = oNewTab.AddGroup("GrpRezepte", "Ansicht")
                ' ... und dieser Gruppe wird ein Button hinzugefügt
                oGrp.AddButton("BtnRezeptListe", "Rezepte Liste", "Liste aller Rezepte anzeigen", My.Resources.RezeptListe_32x32, My.Resources.RezeptListe_32x32, AddressOf BtnRezeptListe)
                oGrp.AddButton("BtnRezeptDetails", "Rezept Details", "Fenster Rezept-Details", My.Resources.RezeptDetails_32x32, My.Resources.RezeptDetails_32x32, AddressOf BtnRezeptDetails)
                oGrp.AddButton("BtnRezeptHinweise", "Rezept Hinweise", "Rezept Verarbeitungshinweise", My.Resources.RezeptHinweise_32x32, My.Resources.RezeptHinweise_32x32, AddressOf BtnRezeptHinweise)
                oGrp.AddButton("BtnRezeptHistorie", "Rezept Historie", "Anzeige der Änderungshistorie der Rezeptur", My.Resources.RezeptHistorie_32x32, My.Resources.RezeptHistorie_32x32, AddressOf BtnRezeptHistorie)
                Dim oGrpPrnt = oNewTab.AddGroup("Printer", "Drucken")
                ' ... und dieser Gruppe wird ein Button hinzugefügt
                oGrpPrnt.AddButton("BtnRezeptListeDrucken", "Drucke Rezeptliste", "Liste aller Rezepte drucken", My.Resources.RezeptDruckenListe_32x32, My.Resources.RezeptDruckenListe_32x32, AddressOf BtnRezeptListeDrucken)
                _ContextTabs.Add(oNewTab)
            End If
            Return _ContextTabs.ToArray
        End Get
    End Property

    Private Sub BtnRezeptListe()
        RezeptListe.Show(DockPanel, DockState.DockLeft)
    End Sub

    Private Sub BtnRezeptDetails()
        RezeptDetails.Show(DockPanel)
    End Sub

    Private Sub BtnRezeptHinweise()
        If RezeptHinweise Is Nothing Then
            RezeptHinweise = New wb_Rezept_Hinweise
        End If
        RezeptHinweise.Show(DockPanel)
    End Sub

    Private Sub BtnRezeptHistorie()
        If RezeptHistorie Is Nothing Then
            RezeptHistorie = New wb_Rezept_Historie
        End If
        RezeptHistorie.Show(DockPanel)
    End Sub

    Private Sub BtnRezeptListeDrucken()
    End Sub

    Protected Overrides Function wbBuildDocContent(ByVal persistString As String) As WeifenLuo.WinFormsUI.Docking.DockContent
        Select Case persistString
            Case "WinBack.wb_Rezept_Liste"
                Return RezeptListe
            Case "WinBack.wb_Rezept_Details"
                Return RezeptDetails
            Case "WinBack.wb_Rezept_Hinweise"
                RezeptHinweise = New wb_Rezept_Hinweise
                Return RezeptHinweise
            Case "WinBack.wb_Rezept_Historie"
                RezeptHistorie = New wb_Rezept_Historie
                Return RezeptHistorie
            Case Else
                Return Nothing
        End Select
    End Function






























    'Implements IExternalFormUserControl
    'Dim DkPnlPath As String = wb_GlobalSettings.DockPanelPath & "wbRezept.xml"

    'Public RezeptListe As New wb_Rezept_Liste
    'Public RezeptDetails As New wb_Rezept_Details
    'Public RezeptHinweise As New wb_Rezept_Hinweise
    'Public RezeptHistorie As New wb_Rezept_Historie

    'Public Function ExecuteCommand(CommandId As String, Parameter As Object) As Object Implements IBasicFormUserControl.ExecuteCommand
    '    'MessageBox.Show("ExecuteCommand!" & vbCrLf & CommandId, "AddIn", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    '    Return Nothing
    'End Function

    '''' <summary>
    '''' Eindeutiger Schlüssel für das Fenster, ggf. Firmenname.AddIn
    '''' </summary>
    'Public ReadOnly Property FormKey As String Implements IBasicFormUserControl.FormKey
    '    Get
    '        Return "@WinBack Rezept-Verwaltung"
    '    End Get
    'End Property

    '''' <summary>
    '''' Routine wird aufgerufen, wenn das Fenster geladen wurde und angezeigt werden soll
    '''' </summary>
    '''' <returns></returns>
    '''' <remarks>Die Caption des Fensters muss mit MyBase.Text gesetzt werde</remarks>
    'Public Function Init() As Boolean Implements IBasicFormUserControl.Init
    '    MyBase.Text = "WinBack Rezept-Verwaltung"
    '    Return True
    'End Function

    '''' <summary>
    '''' Minimale Höhe des UserControls
    '''' </summary>
    'Public ReadOnly Property MinHeight As Integer Implements IBasicFormUserControl.MinHeight
    '    Get
    '        Return Me.MinimumSize.Height
    '    End Get
    'End Property

    '''' <summary>
    '''' Minimale Breite des UserControls
    '''' </summary>
    'Public ReadOnly Property MinWidth As Integer Implements IBasicFormUserControl.MinWidth
    '    Get
    '        Return Me.MinimumSize.Width
    '    End Get
    'End Property

    '''' <summary>
    '''' Gibt an, ob man die Größe dieses UserControls ändern darf
    '''' </summary>
    'Public ReadOnly Property Sizable As Boolean Implements IBasicFormUserControl.Sizable
    '    Get
    '        Return True
    '    End Get
    'End Property

    '''' <summary>
    '''' Bezeichnung und Caption des UserControls
    '''' </summary>
    'Public Shadows ReadOnly Property Text() As String Implements IBasicFormUserControl.Text
    '    Get
    '        Return MyBase.Text
    '    End Get
    'End Property

    'Private _ContextTabs As List(Of GUI.ITab)
    'Public ReadOnly Property ContextTabs As GUI.ITab() Implements IExternalFormUserControl.ContextTabs
    '    Get
    '        If _ContextTabs Is Nothing Then
    '            _ContextTabs = New List(Of GUI.ITab)
    '            ' Fügt dem Ribbon ein neues RibbonTab hinzu
    '            Dim oNewTab = _MenuService.AddContextTab("RezeptVerwaltung", "WinBack-Rezepte", "Verwaltung der WinBack-Rezepturen")
    '            ' Das neue RibbonTab erhält eine Gruppe
    '            Dim oGrp = oNewTab.AddGroup("GrpRezepte", "WinBack Rezepte")
    '            ' ... und dieser Gruppe wird ein Button hinzugefügt
    '            oGrp.AddButton("BtnRezeptPrintList", "Rezept-Liste", "Liste aller Rezepte drucken", My.Resources.UserListe_32x32, My.Resources.UserListe_32x32, AddressOf btnUserPrint)
    '            _ContextTabs.Add(oNewTab)
    '        End If
    '        Return _ContextTabs.ToArray
    '    End Get
    'End Property

    'Public Event Close(sender As Object, e As EventArgs) Implements IBasicFormUserControl.Close
    'Public Sub FormClosed() Implements IBasicFormUserControl.FormClosed
    '    'Anzeige sichern
    '    SaveDockBarConfig()
    '    'alle erzeugten Fenster wieder schliessen !!!
    '    RezeptDetails.Close()
    '    RezeptListe.Close()
    '    RezeptHinweise.Close()
    '    RezeptHistorie.Close()
    'End Sub

    '''' <summary>
    '''' Diese Function wird aufgerufen, wenn das Fenster geschlossen werden soll.
    '''' </summary>
    '''' <param name="Reason"></param>
    '''' <returns>
    '''' False, wenn das Fenster geschlossen werden darf
    '''' True, wenn das Fenster geöffnet bleiben muss
    '''' </returns>
    '''' <remarks></remarks>
    'Public Function FormClosing(Reason As Short) As Boolean Implements IBasicFormUserControl.FormClosing
    '    Return False
    'End Function

    'Private Sub wb_User_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'HashTable mit der Übersetzung der Gruppen-Nummer zu Gruppen-Bezeichnung
    '    wb_User_Shared.LoadGrpTexte()
    '    ' DockBar Konfiguration aus XML-Datei lesen
    '    LoadDockBarConfig()
    'End Sub

    'Private Sub BtnUserNew()
    '    Throw New NotImplementedException
    'End Sub

    'Private Sub BtnUserPasswd()
    '    Throw New NotImplementedException
    'End Sub

    'Private Sub btnUserPrint()
    '    Throw New NotImplementedException
    'End Sub

    'Private Sub BtnUserGroup()
    '    Throw New NotImplementedException
    'End Sub

    'Private _ServiceProvider As Common.IOrgasoftServiceProvider
    'Private _MenuService As Common.IMenuService
    'Private _ViewProvider As IViewProvider

    '''' <summary>
    '''' Konstruktor
    '''' </summary>
    '''' <param name="ServiceProvider">ServiceProvider von OrgaSoft.NET</param>
    '''' <remarks></remarks>
    'Public Sub New(ServiceProvider As Common.IOrgasoftServiceProvider)

    '    ' This call is required by the designer.
    '    InitializeComponent()

    '    ' Add any initialization after the InitializeComponent() call.
    '    _ServiceProvider = ServiceProvider
    '    _MenuService = TryCast(ServiceProvider.GetService(GetType(Common.IMenuService)), Common.IMenuService)
    '    _ViewProvider = TryCast(ServiceProvider.GetService(GetType(IViewProvider)), IViewProvider)

    'End Sub

    'Private Sub SaveDockBarConfig()
    '    DockPanel.SaveAsXml(DkPnlPath)
    'End Sub

    'Private Sub LoadDockBarConfig()
    '    Try
    '        DockPanel.LoadFromXml(DkPnlPath, AddressOf wbBuildDocContent)
    '    Catch ex As Exception
    '    End Try

    '    RezeptHinweise.Show(DockPanel, DockState.Document)
    '    RezeptHinweise.CloseButtonVisible = False
    '    RezeptHistorie.Show(DockPanel, DockState.Document)
    '    RezeptHistorie.CloseButtonVisible = False
    '    RezeptDetails.Show(DockPanel, DockState.DockTop)
    '    RezeptDetails.CloseButtonVisible = False
    '    RezeptListe.Show(DockPanel, DockState.DockLeft)
    '    RezeptListe.CloseButtonVisible = False
    'End Sub

    'Private Function wbBuildDocContent(ByVal persistString As String) As WeifenLuo.WinFormsUI.Docking.DockContent
    '    Select Case persistString
    '        Case "RezeptListe"
    '            Return RezeptListe
    '        Case "RezeptDetails"
    '            Return RezeptDetails
    '        Case "RezeptHinweise"
    '            Return RezeptHinweise
    '        Case "RezeptHistorie"
    '            Return RezeptHistorie
    '        Case Else
    '            Return Nothing
    '    End Select
    'End Function

End Class
