USE winback;
ALTER TABLE Linien ADD L_ProdFiliale INTEGER;
