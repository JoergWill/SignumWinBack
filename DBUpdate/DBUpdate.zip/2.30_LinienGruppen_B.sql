USE winback;
ALTER TABLE LinienGruppen ADD LG_KurzName VARCHAR(5) AFTER LG_Bezeichnung;
