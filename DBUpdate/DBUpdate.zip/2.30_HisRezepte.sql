USE wbdaten;
ALTER TABLE `His_Rezepte` CHANGE COLUMN `H_RZ_Bezeichnung` `H_RZ_Bezeichnung` VARCHAR(60) NULL DEFAULT NULL;