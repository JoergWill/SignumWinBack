USE winback;
UPDATE KomponTypen SET KT_OberGW='99999,9' WHERE KT_Typ_Nr=301 AND KT_ParamNr=202;
