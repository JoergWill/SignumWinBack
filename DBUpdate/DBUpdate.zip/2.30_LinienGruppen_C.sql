USE winback;
ALTER TABLE LinienGruppen ADD LG_StartZeit VARCHAR(14) AFTER LG_Linien;
