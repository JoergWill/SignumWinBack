USE winback;
UPDATE KomponTypen SET KT_OberGW='100,0' WHERE KT_Typ_Nr=102 AND KT_ParamNr=5;
