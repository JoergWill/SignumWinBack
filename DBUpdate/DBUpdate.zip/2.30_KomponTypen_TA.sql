USE winback;
UPDATE KomponTypen SET KT_UnterGW='-1,0' WHERE KT_Typ_Nr=101 AND KT_ParamNr=7;
UPDATE KomponTypen SET KT_UnterGW='-1,0' WHERE KT_Typ_Nr=102 AND KT_ParamNr=7;
