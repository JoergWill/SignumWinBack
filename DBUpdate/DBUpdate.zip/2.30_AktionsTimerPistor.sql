USE winback;
INSERT IGNORE INTO `AktionsTimer` (`AT_idx`, `AT_Quelle_Art`, `AT_Quelle_Nr`, `AT_Quelle_Typ`, `AT_Ziel_Art`, `AT_Ziel_Nr`, `AT_Ziel_Aktion`, `AT_Ziel_Verzoegerung`, `AT_TimingArt`, `AT_Periode`, `AT_Str1`, `AT_Kommentar`) VALUES(90, 0, 0, 'office_pistor', 0, 0, 0, 0, 0, 240, 'OB Pistor', 'Import Pistor-Liste');


