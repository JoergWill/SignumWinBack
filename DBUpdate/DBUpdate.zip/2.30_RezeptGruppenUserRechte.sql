USE winback;
DELETE FROM ItemParameter WHERE IP_ItemTyp=230;

INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 99, 99, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 101, 1, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 102, 2, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 103, 3, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 104, 4, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 105, 5, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 106, 6, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 107, 7, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 1, 405, 108, 8, 2, 0, NULL, NULL);

INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 99, 99, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 101, 1, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 102, 2, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 103, 3, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 104, 4, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 105, 5, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 106, 6, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 107, 7, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 2, 405, 108, 8, 2, 0, NULL, NULL);

INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 99, 99, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 101, 1, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 102, 2, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 103, 3, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 104, 4, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 105, 5, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 106, 6, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 107, 7, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 3, 405, 108, 8, 2, 0, NULL, NULL);

INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 99, 99, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 101, 1, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 102, 2, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 103, 3, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 104, 4, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 105, 5, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 106, 6, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 107, 7, 2, 0, NULL, NULL);
INSERT INTO ItemParameter (IP_ItemTyp, IP_ItemID, IP_ItemAttr, IP_Lfd_Nr, IP_Wert1int, IP_Wert2int, IP_Wert3int, IP_Wert4str, IP_Wert5str) VALUES (230, 4, 405, 108, 8, 2, 0, NULL, NULL);
