USE winback;
INSERT IGNORE INTO ItemParameter ('IP_ItemTyp','IP_ItemAttr','IP_Lfd_Nr','IP_Wert5str') VALUES ('3010', '3010', '1', 'Quellstück');
INSERT IGNORE INTO ItemParameter ('IP_ItemTyp','IP_ItemAttr','IP_Lfd_Nr','IP_Wert5str') VALUES ('3010', '3010', '2', 'Vorteig');
INSERT IGNORE INTO ItemParameter ('IP_ItemTyp','IP_ItemAttr','IP_Lfd_Nr','IP_Wert5str') VALUES ('3010', '3010', '3', 'Hauptteig');

INSERT IGNORE INTO ItemTypen ('IT_ItemTyp','IT_Bezeichnung') VALUES ('3010', 'Texte ProdStufen');
